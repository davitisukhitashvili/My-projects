let playerScore = 0;
let computerScore = 0;

function playGame(playerChoice) {
  const choices = ['rock', 'paper', 'scissors'];
  const computerChoice = choices[Math.floor(Math.random() * choices.length)];

  const result = getResult(playerChoice, computerChoice);

  if (result === 'win') {
    playerScore++;
  } else if (result === 'lose') {
    computerScore++;
  }

  updateScore();
  displayResult(result, playerChoice, computerChoice);
}

function getResult(player, computer) {
  if (player === computer) {
    return 'draw';
  } else if (
    (player === 'rock' && computer === 'scissors') ||
    (player === 'paper' && computer === 'rock') ||
    (player === 'scissors' && computer === 'paper')
  ) {
    return 'win';
  } else {
    return 'lose';
  }
}

function updateScore() {
  document.getElementById('score').innerText = `Player: ${playerScore} | Computer: ${computerScore}`;
}

function displayResult(result, player, computer) {
  const resultMessage =
    result === 'draw'
      ? 'It\'s a draw!'
      : result === 'win'
      ? `You win! ${player} beats ${computer}.`
      : `You lose! ${computer} beats ${player}.`;

  document.getElementById('result').innerText = resultMessage;
}
