document.addEventListener("DOMContentLoaded", function () {
    loadTasks();
  });
  
  function loadTasks() {
    const taskList = document.getElementById("task-list");
    taskList.innerHTML = "";
    const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
  
    tasks.forEach(function (task, index) {
      const li = createTaskElement(task.text, task.color, index);
      taskList.appendChild(li);
    });
  }
  
  function addTask() {
    const newTaskInput = document.getElementById("new-task");
    const taskColorInput = document.getElementById("task-color");
  
    const newTask = newTaskInput.value.trim();
    const taskColor = taskColorInput.value;
  
    if (newTask !== "") {
      const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
      tasks.push({ text: newTask, color: taskColor });
      localStorage.setItem("tasks", JSON.stringify(tasks));
      newTaskInput.value = "";
      loadTasks();
    }
  }
  
  function editTask(index) {
    const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    const updatedTaskText = prompt("Edit task:", tasks[index].text);
    
    if (updatedTaskText !== null) {
      tasks[index].text = updatedTaskText.trim();
      localStorage.setItem("tasks", JSON.stringify(tasks));
      loadTasks();
    }
  }
  
  function deleteTask(index) {
    const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    tasks.splice(index, 1);
    localStorage.setItem("tasks", JSON.stringify(tasks));
    loadTasks();
  }
  
  function createTaskElement(text, color, index) {
    const li = document.createElement("li");
    li.innerHTML = `<span>${text}</span>
                    <button onclick="editTask(${index})">Edit</button>
                    <button onclick="deleteTask(${index})">Delete</button>`;
    li.style.backgroundColor = color; // Set the background color for the entire task tab
    return li;
  }
  