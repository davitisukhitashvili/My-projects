document.addEventListener('DOMContentLoaded', function() {
  const themeToggleBtn = document.getElementById('theme-toggle');
  const countriesListEl = document.getElementById('countries-list');
  const searchBox = document.getElementById('search-box');
  const regionFilter = document.getElementById('region-filter');
  let countriesData = [];

  themeToggleBtn.addEventListener('click', toggleTheme);
  searchBox.addEventListener('input', () => filterCountries(searchBox.value, regionFilter.value));
  regionFilter.addEventListener('change', () => filterCountries(searchBox.value, regionFilter.value));

  fetchCountries();

  function toggleTheme() {
    document.body.classList.toggle('dark-theme');
    themeToggleBtn.textContent = document.body.classList.contains('dark-theme') ? 'Light Mode' : 'Dark Mode';
    themeToggleBtn.style.color = document.body.classList.contains('dark-theme') ? 'white' : 'black';
    
  }

  function fetchCountries() {
    fetch('https://restcountries.com/v3.1/all')
      .then(response => response.json())
      .then(data => {
        countriesData = data;
        populateCountries(data);
        populateRegions(data);
      });
  }

  function populateCountries(countries) {
    countriesListEl.innerHTML = '';
    countries.forEach(country => {
      countriesListEl.innerHTML += `
        <div class="country-card">
          <img src="${country.flags.png}" alt="Flag of ${country.name.common}">
          <h3>${country.name.common}</h3>
          <p>Population: ${country.population.toLocaleString()}</p>
          <p>Region: ${country.region}</p>
          <p>Capital: ${country.capital}</p>
        </div>
      `;
    });
  }

  function populateRegions(countries) {
    const regions = Array.from(new Set(countries.map(country => country.region)));
    regionFilter.innerHTML = '<option value="">Filter By Region</option>';
    regions.forEach(region => {
      if (region) {
        regionFilter.innerHTML += `<option value="${region}">${region}</option>`;
      }
    });
  }

  function filterCountries(searchText, region) {
    let filteredCountries = countriesData;

    if (searchText) {
      filteredCountries = filteredCountries.filter(country =>
        country.name.common.toLowerCase().includes(searchText.toLowerCase())
      );
    }

    if (region) {
      filteredCountries = filteredCountries.filter(country => country.region === region);
    }

    populateCountries(filteredCountries);
  }
});
